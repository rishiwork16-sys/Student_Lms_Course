package com.finallms.backend.enums;

public enum QuestionType {
    MCQ,
    FILE_UPLOAD
}
