package com.finallms.backend.enums;

public enum PaymentStatus {
    CREATED,
    SUCCESS,
    FAILED,
    REFUNDED
}

