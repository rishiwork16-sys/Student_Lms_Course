package com.finallms.backend.enums;

public enum SubmissionStatus {
    PENDING,
    SUBMITTED,
    GRADED
}
